#pragma once

#include<string>
#include<vector>
#include<iostream>
#include<map>
#include"Cards.h"
#include"Deck.h"

using namespace std;
//predefine the classed
class Cards;
class Deck;

class Hand {
public:
	Hand();
	Hand(const Hand& hand);// a copy constructor
	~Hand(); //deconstructor because of vector instace variable
	vector<Cards>* getHand();
	void setHand(vector<Cards>* toSet);// set a vector to hand
	void add(Cards& card); // add a card to hand
private:
	vector<Cards>* hand; // instance varibale to store cards
	friend ostream& operator<<(ostream&, const Hand&);
};
