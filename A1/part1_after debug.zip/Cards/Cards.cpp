#include<vector>
#include<string>
#include<cstdlib>
#include<iostream>
#include<map>
#include "Hand.h"
#include"Cards.h"
#include"Deck.h"


Cards::Cards() {
	type = "Bomb";
}

Cards::Cards(std::string c) {
	type = c;
}

Cards::Cards(const Cards &card) {
	 type = card.type;
 }

std::string Cards::getType() {
	return type;
}

std::ostream& operator<<(std::ostream& ostream, const Cards& card)
{
	return ostream << "Card is of type: " << card.type;
}


void Cards::play(Deck *deck,Hand *hand) {
	std::vector<Cards> *temp = hand->getHand();// get hand pointer to manage hand vector
	int size = temp->size(); // obtain the size to traverse the vector
	for (int i = size - 1; i >= 0; i--) {// back to front so that to pop-back
		Cards *current = &(temp->at(i)); //obtain current pointer
		std::cout << "A card is played and " << *current <<std:: endl;// display the shown card
		std::vector<Cards>* loss = hand->getHand();// obtain hand
		std::vector<Cards>* obtain = deck->getAvailableCards();// obtain deck cards
		deck->insertCard(temp->at(i));//deck pile gets one card
		loss->pop_back();//hand loses one card
		
	}
	
	
}	